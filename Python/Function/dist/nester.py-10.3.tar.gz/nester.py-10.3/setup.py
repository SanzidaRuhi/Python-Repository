from distutils.core import setup

setup(
        name            = 'nester.py',
        version         = '10.3',
        py_modeles      = ['nester'],
        author          = 'use a cabeça',
        author_email    = 'useacabeca@gmail.com',
        url             = 'http://www.headfirstlabs.com',
        description     = 'um exemplo',
    )
