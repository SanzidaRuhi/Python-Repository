from distutils.core import setup

setup(
        name            = 'nester.py',
        version         = '1.3.0',
        py_modeles      = ['nester'],
        author          = 'use a cabeça',
        author_email    = 'useacabeca@gmail.com',
        url             = 'http://www.headfirstlabs.com',
        description     = 'um exemplo',
    )
